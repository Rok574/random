# Xitter Native iOS — SwiftUI starter v5

A native SwiftUI-first client shell for Xitter, with instance selection, native sign-in UI, settings, cached timeline, and an API boundary designed for verified endpoint integration. It is **not** a web embed.

## Features included
- First-launch instance setup; edit the instance URL later in Settings
- Native username/password sign-in screen and password visibility toggle
- Form-based sign-in to the instance's `POST /login` endpoint; password is not persisted and session cookies are received from the server
- Native timeline UI with live `HomeTimeline` / `HomeLatestTimeline` reads from the instance
- Automatic feed polling every 45 seconds while the timeline is visible, plus pull-to-refresh and a new-post count
- Cached feed JSON scoped per instance, connectivity indicator, and offline fallback
- Compose, like/repost/bookmark controls are still local preview behavior
- URLSession with HTTP cache configuration and `waitsForConnectivity`
- Native settings screen with instance validation, cache clearing, and sign-out UI

## Current integration status
Login is connected to the server code you supplied: the app POSTs URL-encoded `username` and `password` to `/login`, follows the successful redirect, and checks for the server-issued `auth_token` and `ct0` cookies. The app does not include or require an example cookie. The server also issues `twid`; all session cookies are managed by `URLSession` cookie storage.

Timeline reads are now connected to the instance's GraphQL-shaped handlers. The server's `src/graphql.ts` maps `HomeTimeline` to For You and `HomeLatestTimeline` to Following, with response entries containing tweet results. The app polls the selected timeline every 45 seconds while the feed view is active, merges by replacing the visible first page with the latest server response, and caches it per instance. Compose and like/repost/bookmark controls are still local preview behavior; registration is not implemented natively. This is live feed reading, not yet a fully live social client.

## Open in Xcode
1. On a Mac, install Xcode 15+ and XcodeGen (`brew install xcodegen`).
2. In this directory run `xcodegen generate`.
3. Open `XitterNative.xcodeproj`, set your own bundle identifier, choose your iPhone, and Run.
4. Login is enabled. Keep demo mode on until timeline and write operations are implemented and tested.

Deployment target: iOS 16.0.

## Instance setup
The first screen asks for an instance URL, defaulting to `https://xitter.opuadm.com`. You can change it later from the Settings tab. Use HTTPS for public instances. The instance must expose the form login route and permit requests from the device.

## Remaining API integration
Against an instance you are authorized to use:
1. Implement live compose, like, repost, bookmark and server-side logout using verified operation payloads and CSRF headers.
2. Add native registration only after confirming invite, verification and second-factor requirements.
3. Test slow/offline networks, expired sessions, server errors, and multiple instances.

## Offline behavior
Previously loaded timeline JSON is saved in the app's Caches directory and rendered at launch. HTTP responses can use URLCache. This is best-effort offline support, not a guarantee that every media asset or action works offline. Real actions should be queued only after defining safe retry/idempotency rules.


## Build an IPA with GitHub Actions

1. Push this project to a GitHub repository.
2. Ensure `XitterNativeIOS_v5/project.yml` and `.github/workflows/build-ipa.yml` are committed at the paths shown.
3. In GitHub, open **Actions → Build iOS IPA → Run workflow**. A push to `main` or `master` that changes this project also triggers a build.
4. Open the completed run and download the **Xitter-unsigned-ipa** artifact.

The workflow builds an **unsigned** IPA because signing requires your Apple Developer signing identity and provisioning profile. An unsigned IPA is useful as a build artifact, but it generally cannot be installed on a physical iPhone until it is signed with a valid certificate/profile. Set the repository variable `IOS_BUNDLE_ID` to your own unique bundle identifier before distributing or signing the app. Do not commit signing certificates, passwords, or provisioning profiles to the repository.
