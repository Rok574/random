import SwiftUI

@main
struct XitterNativeApp: App {
    @StateObject private var settings = InstanceSettings()

    var body: some Scene {
        WindowGroup {
            AppRootView()
                .environmentObject(settings)
                .preferredColorScheme(.dark)
        }
    }
}

struct AppRootView: View {
    @EnvironmentObject private var settings: InstanceSettings

    var body: some View {
        Group {
            if settings.signedInUsername != nil,
               let url = settings.baseURL,
               !XitterAPI(baseURL: url).hasSession() {
                Color.clear.onAppear { settings.signOutLocally() }
            } else if !settings.hasCompletedSetup {
                InstanceSetupView()
            } else if settings.signedInUsername == nil {
                LoginView()
            } else {
                MainView()
            }
        }
        .animation(.easeInOut(duration: 0.2), value: settings.hasCompletedSetup)
        .animation(.easeInOut(duration: 0.2), value: settings.signedInUsername)
    }
}
