import SwiftUI

struct ComposeView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""
    let onPost: (String) -> Void

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 14) {
                HStack(alignment: .top, spacing: 12) {
                    Circle().fill(Color.cyan.opacity(0.8)).frame(width: 42, height: 42).overlay(Text("Y").fontWeight(.bold))
                    TextEditor(text: $text).scrollContentBackground(.hidden).font(.system(size: 17)).frame(minHeight: 150)
                        .overlay(alignment: .topLeading) {
                            if text.isEmpty { Text("What's happening?").foregroundStyle(.gray).padding(.top, 8).padding(.leading, 5).allowsHitTesting(false) }
                        }
                }
                Spacer()
                Text("\(text.count)/280").font(.caption).foregroundStyle(text.count > 280 ? .red : .secondary)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }.padding().background(Color.black).navigationTitle("New post").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() }.foregroundStyle(.white) }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Post") {
                            let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
                            guard !trimmed.isEmpty, trimmed.count <= 280 else { return }
                            onPost(trimmed); dismiss()
                        }.fontWeight(.bold).disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || text.count > 280).foregroundStyle(.cyan)
                    }
                }
        }.preferredColorScheme(.dark)
    }
}
