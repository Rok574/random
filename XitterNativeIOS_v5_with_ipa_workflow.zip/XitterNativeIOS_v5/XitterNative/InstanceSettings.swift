import Foundation

@MainActor
final class InstanceSettings: ObservableObject {
    @Published var baseURLString: String {
        didSet { UserDefaults.standard.set(baseURLString, forKey: "xitter.instanceURL") }
    }
    @Published var hasCompletedSetup: Bool {
        didSet { UserDefaults.standard.set(hasCompletedSetup, forKey: "xitter.didSetup") }
    }
    @Published var signedInUsername: String? {
        didSet {
            if let signedInUsername {
                UserDefaults.standard.set(signedInUsername, forKey: "xitter.username")
            } else {
                UserDefaults.standard.removeObject(forKey: "xitter.username")
            }
        }
    }

    init() {
        baseURLString = UserDefaults.standard.string(forKey: "xitter.instanceURL") ?? AppConfig.defaultInstanceURL
        hasCompletedSetup = UserDefaults.standard.bool(forKey: "xitter.didSetup")
        signedInUsername = UserDefaults.standard.string(forKey: "xitter.username")
    }

    var baseURL: URL? {
        let raw = baseURLString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard var components = URLComponents(string: raw),
              let scheme = components.scheme?.lowercased(),
              ["https", "http"].contains(scheme),
              let host = components.host, !host.isEmpty,
              components.user == nil, components.password == nil else { return nil }
        components.path = components.path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        components.query = nil
        components.fragment = nil
        return components.url
    }

    func normalizeInstanceURL() -> Bool {
        guard let url = baseURL else { return false }
        baseURLString = url.absoluteString.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        return true
    }

    func signOutLocally() {
        signedInUsername = nil
    }
}
