import SwiftUI

struct BrandMark: View {
    var body: some View {
        Image(systemName: "bird.fill")
            .font(.system(size: 34, weight: .bold))
            .foregroundStyle(.white)
            .frame(width: 72, height: 72)
            .background(Color.cyan.gradient, in: RoundedRectangle(cornerRadius: 24))
            .shadow(color: .cyan.opacity(0.22), radius: 20, y: 8)
    }
}

struct InstanceSetupView: View {
    @EnvironmentObject private var settings: InstanceSettings
    @State private var draft = ""
    @State private var error: String?
    @State private var showingInstanceEditor = false

    var body: some View {
        VStack(spacing: 24) {
            HStack {
                Spacer()
                Button { showingInstanceEditor = true } label: {
                    Image(systemName: "gearshape.fill")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 42, height: 42)
                        .background(Color.white.opacity(0.08), in: Circle())
                }
                .accessibilityLabel("Change instance")
            }
            Spacer()
            BrandMark()
            VStack(spacing: 8) {
                Text("Your Xitter, your instance")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .multilineTextAlignment(.center)
                Text("Choose the server you want to connect to. You can change it any time.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            VStack(alignment: .leading, spacing: 10) {
                Text("INSTANCE URL").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                HStack(spacing: 10) {
                    Image(systemName: "server.rack").foregroundStyle(.cyan)
                    TextField("https://your-xitter-instance.example", text: $draft)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                        .autocorrectionDisabled()
                }
                .padding(15)
                .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14))
                if let error { Text(error).font(.caption).foregroundStyle(.red) }
            }
            Button {
                settings.baseURLString = draft
                if settings.normalizeInstanceURL() {
                    settings.hasCompletedSetup = true
                    error = nil
                } else {
                    error = "Enter a valid http:// or https:// instance URL."
                }
            } label: {
                Text("Continue").fontWeight(.bold).frame(maxWidth: .infinity).padding(.vertical, 16)
                    .background(Color.cyan, in: RoundedRectangle(cornerRadius: 16))
                    .foregroundStyle(.black)
            }
            Spacer()
            Text("Native SwiftUI • Offline-friendly").font(.caption).foregroundStyle(.tertiary)
        }
        .padding(24)
        .onAppear { draft = settings.baseURLString }
        .background(Color.black.ignoresSafeArea())
        .sheet(isPresented: $showingInstanceEditor) {
            NavigationStack { InstanceEditorSheet() }
                .presentationDetents([.medium])
        }
    }
}

struct LoginView: View {
    @EnvironmentObject private var settings: InstanceSettings
    @State private var username = ""
    @State private var password = ""
    @State private var showPassword = false
    @State private var isSigningIn = false
    @State private var error: String?
    @State private var showInstanceEditor = false
    @State private var showRegisterInfo = false

    var body: some View {
        VStack(spacing: 22) {
            HStack {
                Button { showInstanceEditor = true } label: {
                    Image(systemName: "gearshape.fill")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 42, height: 42)
                        .background(Color.white.opacity(0.08), in: Circle())
                }
                .accessibilityLabel("Change instance")
                Spacer()
                Text(settings.baseURL?.host ?? settings.baseURLString)
                    .font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer()
            BrandMark()
            VStack(spacing: 8) {
                Text("Welcome to Xitter")
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                Text("Sign in to \(settings.baseURL?.host ?? settings.baseURLString)")
                    .font(.subheadline).foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            VStack(spacing: 12) {
                inputRow(icon: "person") {
                    TextField("Username", text: $username)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                }
                inputRow(icon: "lock") {
                    Group {
                        if showPassword { TextField("Password", text: $password) }
                        else { SecureField("Password", text: $password) }
                    }
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                    Button { showPassword.toggle() } label: {
                        Image(systemName: showPassword ? "eye.slash" : "eye").foregroundStyle(.secondary)
                    }
                }
            }
            if let error {
                Text(error).font(.footnote).foregroundStyle(.red).frame(maxWidth: .infinity, alignment: .leading)
            }
            Button { Task { await signIn() } } label: {
                HStack {
                    if isSigningIn { ProgressView().tint(.black) }
                    Text(isSigningIn ? "Signing in…" : "Sign in").fontWeight(.bold)
                }
                .frame(maxWidth: .infinity).padding(.vertical, 16)
                .background(Color.cyan, in: RoundedRectangle(cornerRadius: 16)).foregroundStyle(.black)
            }
            .disabled(isSigningIn || username.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || password.isEmpty)

            Button("Create account / Register") { showRegisterInfo = true }
                .font(.subheadline.weight(.semibold)).foregroundStyle(.cyan)
            Text("Your password is sent to the selected instance for sign-in and is not saved by this app.")
                .font(.caption).foregroundStyle(.tertiary).multilineTextAlignment(.center)
            Spacer()
        }
        .padding(24)
        .background(Color.black.ignoresSafeArea())
        .sheet(isPresented: $showInstanceEditor) {
            NavigationStack { InstanceEditorSheet() }
                .presentationDetents([.medium])
        }
        .alert("Registration", isPresented: $showRegisterInfo) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("Account creation depends on whether the selected Xitter instance allows registration. Native registration is not connected in this starter.")
        }
    }

    @ViewBuilder
    private func inputRow<Content: View>(icon: String, @ViewBuilder content: () -> Content) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon).foregroundStyle(.cyan).frame(width: 20)
            content().font(.system(size: 16))
        }
        .padding(15)
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14))
    }

    @MainActor
    private func signIn() async {
        error = nil
        guard let baseURL = settings.baseURL else {
            error = "Your instance URL is invalid. Change it using the gear icon."
            return
        }
        isSigningIn = true
        defer { isSigningIn = false }
        do {
            try await XitterAPI(baseURL: baseURL).signIn(username: username, password: password)
            settings.signedInUsername = username.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "@", with: "", options: [.anchored])
        } catch {
            self.error = error.localizedDescription
        }
        password = ""
    }
}

struct InstanceEditorSheet: View {
    @EnvironmentObject private var settings: InstanceSettings
    @Environment(\.dismiss) private var dismiss
    @State private var draft = ""
    @State private var error: String?

    var body: some View {
        Form {
            Section("Instance URL") {
                TextField("https://instance.example", text: $draft)
                    .textInputAutocapitalization(.never)
                    .keyboardType(.URL)
                    .autocorrectionDisabled()
                if let error { Text(error).font(.caption).foregroundStyle(.red) }
                Text("Use an HTTPS URL for public instances.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section {
                Button("Save and use instance") {
                    settings.baseURLString = draft
                    if settings.normalizeInstanceURL() {
                        error = nil
                        dismiss()
                    } else {
                        error = "Enter a valid http:// or https:// URL."
                    }
                }
                .fontWeight(.semibold)
            }
        }
        .navigationTitle("Change instance")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Cancel") { dismiss() }
            }
        }
        .onAppear { draft = settings.baseURLString }
    }
}
