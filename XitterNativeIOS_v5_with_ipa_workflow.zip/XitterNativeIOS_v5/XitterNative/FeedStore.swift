import Foundation
import Combine
import Network

@MainActor
final class FeedStore: ObservableObject {
    @Published private(set) var posts: [Post] = []
    @Published var selectedFeed = "For you"
    @Published private(set) var isRefreshing = false
    @Published private(set) var isOnline = true
    @Published var statusMessage: String?
    @Published private(set) var lastUpdated: Date?

    private let monitor = NWPathMonitor()
    private let monitorQueue = DispatchQueue(label: "xitter.network.monitor")
    private var refreshLoopStarted = false
    private var currentInstanceKey: String { UserDefaults.standard.string(forKey: "xitter.instanceURL") ?? AppConfig.defaultInstanceURL }
    private var cacheURL: URL {
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        let safeKey = currentInstanceKey.replacingOccurrences(of: "[^A-Za-z0-9]", with: "_", options: .regularExpression)
        return dir.appendingPathComponent("xitter-feed-\(safeKey)-v1.json")
    }

    init() {
        loadCache()
        monitor.pathUpdateHandler = { [weak self] path in
            Task { @MainActor in self?.isOnline = path.status == .satisfied }
        }
        monitor.start(queue: monitorQueue)
    }

    deinit { monitor.cancel() }

    /// Initial fetch followed by lightweight polling every 45 seconds while the feed is visible.
    func startAutoRefresh() async {
        guard !refreshLoopStarted else { return }
        refreshLoopStarted = true
        await refresh()
        while !Task.isCancelled {
            do { try await Task.sleep(for: .seconds(45)) } catch { break }
            if Task.isCancelled { break }
            await refresh()
        }
        refreshLoopStarted = false
    }

    func refresh() async {
        guard !isRefreshing else { return }
        guard isOnline else { statusMessage = "Offline — showing saved posts"; return }
        guard let url = URL(string: currentInstanceKey), XitterAPI(baseURL: url).hasSession() else {
            statusMessage = "Your session has expired. Sign in again to refresh the timeline."
            return
        }
        isRefreshing = true
        defer { isRefreshing = false }
        do {
            let api = XitterAPI(baseURL: url)
            let incoming = try await api.fetchTimeline(kind: selectedFeed)
            let oldIDs = Set(posts.map(\.id))
            let newCount = incoming.filter { !oldIDs.contains($0.id) }.count
            // The server returns the newest page first. Keep server state authoritative.
            posts = incoming
            lastUpdated = .now
            saveCache()
            if newCount > 0 {
                statusMessage = "Updated just now · \(newCount) new \(newCount == 1 ? "post" : "posts")"
            } else {
                statusMessage = "Updated just now · no new posts"
            }
        } catch {
            statusMessage = "Refresh failed: \(error.localizedDescription)"
            if posts.isEmpty { loadCache() }
        }
    }

    // Demo compose and engagement are intentionally not wired to write operations yet.
    func addDemoPost(_ text: String) {
        let post = Post(id: UUID().uuidString, displayName: "You", username: "you", text: text, timestamp: .now, avatarURL: nil, imageURL: nil, replies: 0, reposts: 0, likes: 0, views: 0, verified: false, liked: false, reposted: false, bookmarked: false)
        posts.insert(post, at: 0); saveCache()
        statusMessage = "Saved locally — server posting isn't connected yet"
    }
    func toggleLike(_ post: Post) {
        guard let i = posts.firstIndex(where: { $0.id == post.id }) else { return }
        posts[i].liked.toggle(); posts[i].likes = max(0, posts[i].likes + (posts[i].liked ? 1 : -1)); saveCache()
    }
    func toggleRepost(_ post: Post) {
        guard let i = posts.firstIndex(where: { $0.id == post.id }) else { return }
        posts[i].reposted.toggle(); posts[i].reposts = max(0, posts[i].reposts + (posts[i].reposted ? 1 : -1)); saveCache()
    }
    func toggleBookmark(_ post: Post) {
        guard let i = posts.firstIndex(where: { $0.id == post.id }) else { return }
        posts[i].bookmarked.toggle(); saveCache()
    }
    private func loadCache() {
        guard let data = try? Data(contentsOf: cacheURL), let decoded = try? JSONDecoder().decode([Post].self, from: data) else { return }
        posts = decoded
    }
    private func saveCache() {
        guard let data = try? JSONEncoder().encode(posts) else { return }
        try? data.write(to: cacheURL, options: .atomic)
    }
}
