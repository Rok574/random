import Foundation

enum AppConfig {
    static let defaultInstanceURL = "https://xitter.opuadm.com"
    // Login uses the instance's form endpoint; timeline/actions remain preview-only.
    static let demoMode = true
}
