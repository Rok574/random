import SwiftUI

struct MainView: View {
    @StateObject private var store = FeedStore()
    @State private var showingComposer = false
    @State private var selectedTab = 0
    @State private var showingSettings = false

    var body: some View {
        VStack(spacing: 0) {
            header
            feedPicker
            if let message = store.statusMessage {
                Text(message).font(.caption).foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 16).padding(.vertical, 8)
            }
            ScrollView {
                LazyVStack(spacing: 0) {
                    ForEach(store.posts) { post in
                        PostCard(post: post, onLike: { store.toggleLike(post) }, onRepost: { store.toggleRepost(post) }, onBookmark: { store.toggleBookmark(post) })
                        Divider().overlay(Color.white.opacity(0.08))
                    }
                }
            }.refreshable { await store.refresh() }
            bottomBar
        }
        .background(Color.black.ignoresSafeArea())
        .task { await store.startAutoRefresh() }
        .sheet(isPresented: $showingComposer) {
            ComposeView { text in store.addDemoPost(text) }.presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $showingSettings) { NavigationStack { SettingsView() } }
    }

    private var header: some View {
        HStack {
            Image(systemName: "bird.fill").font(.system(size: 25, weight: .bold)).foregroundStyle(.white)
            Spacer()
            VStack(spacing: 2) {
                Text("Xitter").font(.system(size: 20, weight: .bold))
                if let updated = store.lastUpdated {
                    Text("Updated \(updated, style: .relative) ago").font(.system(size: 10)).foregroundStyle(.gray)
                }
            }
            Spacer()
            Button { showingSettings = true } label: {
                Image(systemName: "gearshape").font(.system(size: 18, weight: .semibold)).foregroundStyle(.white)
                    .frame(width: 40, height: 40).background(Color.white.opacity(0.08), in: Circle())
            }.accessibilityLabel("Settings")
            Button { Task { await store.refresh() } } label: {
                Image(systemName: store.isRefreshing ? "arrow.triangle.2.circlepath" : (store.isOnline ? "arrow.clockwise" : "wifi.slash"))
                    .font(.system(size: 17, weight: .semibold)).foregroundStyle(store.isOnline ? .white : .orange)
                    .frame(width: 40, height: 40).background(Color.white.opacity(0.08), in: Circle())
            }.accessibilityLabel("Refresh timeline")
        }.padding(.horizontal, 16).padding(.vertical, 8)
    }

    private var feedPicker: some View {
        HStack(spacing: 0) {
            ForEach(["For you", "Following"], id: \.self) { item in
                Button { store.selectedFeed = item; Task { await store.refresh() } } label: {
                    VStack(spacing: 10) {
                        Text(item).font(.system(size: 15, weight: store.selectedFeed == item ? .bold : .medium))
                            .foregroundStyle(store.selectedFeed == item ? .white : .gray)
                        Capsule().fill(store.selectedFeed == item ? Color.cyan : .clear).frame(width: 56, height: 4)
                    }.frame(maxWidth: .infinity).contentShape(Rectangle())
                }.buttonStyle(.plain)
            }
        }.padding(.top, 4).overlay(alignment: .bottom) { Divider().overlay(Color.white.opacity(0.08)) }
    }

    private var bottomBar: some View {
        HStack {
            tabButton("house.fill", index: 0)
            Spacer()
            tabButton("magnifyingglass", index: 1)
            Spacer()
            Button { showingComposer = true } label: {
                Image(systemName: "plus").font(.system(size: 21, weight: .bold)).foregroundStyle(.black)
                    .frame(width: 48, height: 48).background(Color.cyan, in: Circle())
            }
            Spacer()
            tabButton("bell", index: 2)
            Spacer()
            tabButton("envelope", index: 3)
        }.padding(.horizontal, 26).padding(.top, 10).padding(.bottom, 4).background(.black)
            .overlay(alignment: .top) { Divider().overlay(Color.white.opacity(0.1)) }
    }

    private func tabButton(_ symbol: String, index: Int) -> some View {
        Button { selectedTab = index } label: {
            Image(systemName: symbol).font(.system(size: 21, weight: .medium))
                .foregroundStyle(selectedTab == index ? .white : .gray).frame(width: 32, height: 40)
        }.buttonStyle(.plain)
    }
}
