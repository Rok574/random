import SwiftUI

struct PostCard: View {
    let post: Post
    let onLike: () -> Void
    let onRepost: () -> Void
    let onBookmark: () -> Void

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Circle().fill(LinearGradient(colors: [.cyan.opacity(0.9), .blue.opacity(0.6)], startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 42, height: 42).overlay(Text(String(post.displayName.prefix(1)).uppercased()).font(.system(size: 17, weight: .bold)))
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 4) {
                    Text(post.displayName).fontWeight(.bold).foregroundStyle(.white).lineLimit(1)
                    if post.verified { Image(systemName: "checkmark.seal.fill").foregroundStyle(.cyan).font(.system(size: 13)) }
                    Text("@\(post.username)").foregroundStyle(.gray).lineLimit(1)
                    Text("· \(post.timestamp, style: .relative)").foregroundStyle(.gray).lineLimit(1)
                    Spacer(minLength: 0); Image(systemName: "ellipsis").foregroundStyle(.gray)
                }.font(.system(size: 13))
                Text(post.text).font(.system(size: 15)).foregroundStyle(.white.opacity(0.95)).fixedSize(horizontal: false, vertical: true)
                if let url = post.imageURL {
                    AsyncImage(url: url) { image in image.resizable().scaledToFill() } placeholder: {
                        RoundedRectangle(cornerRadius: 16).fill(Color.white.opacity(0.06)).overlay(ProgressView())
                    }.frame(maxWidth: .infinity).frame(height: 190).clipped().clipShape(RoundedRectangle(cornerRadius: 16))
                }
                HStack {
                    metric("bubble", value: post.replies); Spacer(minLength: 8)
                    Button(action: onRepost) { Label(post.reposts.compact, systemImage: "arrow.2.squarepath").foregroundStyle(post.reposted ? .green : .gray) }.buttonStyle(.plain)
                    Spacer(minLength: 8)
                    Button(action: onLike) { Label(post.likes.compact, systemImage: post.liked ? "heart.fill" : "heart").foregroundStyle(post.liked ? .pink : .gray) }.buttonStyle(.plain)
                    Spacer(minLength: 8); metric("chart.bar", value: post.views); Spacer(minLength: 8)
                    Button(action: onBookmark) { Image(systemName: post.bookmarked ? "bookmark.fill" : "bookmark").foregroundStyle(post.bookmarked ? .cyan : .gray) }.buttonStyle(.plain)
                    Image(systemName: "square.and.arrow.up").foregroundStyle(.gray)
                }.font(.system(size: 12)).padding(.top, 4)
            }
        }.padding(.horizontal, 16).padding(.vertical, 14).contentShape(Rectangle())
    }

    private func metric(_ symbol: String, value: Int) -> some View { Label(value.compact, systemImage: symbol).foregroundStyle(.gray) }
}

private extension Int {
    var compact: String {
        if self >= 1_000_000 { return String(format: "%.1fm", Double(self) / 1_000_000) }
        if self >= 1_000 { return String(format: "%.1fk", Double(self) / 1_000) }
        return "\(self)"
    }
}
