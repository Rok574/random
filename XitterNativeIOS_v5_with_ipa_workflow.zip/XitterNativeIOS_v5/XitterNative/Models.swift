import Foundation

struct Post: Identifiable, Codable, Equatable {
    var id: String
    var displayName: String
    var username: String
    var text: String
    var timestamp: Date
    var avatarURL: URL?
    var imageURL: URL?
    var replies: Int
    var reposts: Int
    var likes: Int
    var views: Int
    var verified: Bool
    var liked: Bool
    var reposted: Bool
    var bookmarked: Bool

    static let samples: [Post] = [
        Post(id: "p1", displayName: "Sky", username: "sky", text: "The best apps feel instant, even when the connection isn't. ✨", timestamp: .now.addingTimeInterval(-300), avatarURL: nil, imageURL: nil, replies: 18, reposts: 42, likes: 286, views: 9200, verified: true, liked: false, reposted: false, bookmarked: false),
        Post(id: "p2", displayName: "Mika", username: "mikacodes", text: "A little reminder to ship the simple version first, then make it delightful.", timestamp: .now.addingTimeInterval(-2400), avatarURL: nil, imageURL: nil, replies: 7, reposts: 12, likes: 103, views: 3100, verified: false, liked: true, reposted: false, bookmarked: false),
        Post(id: "p3", displayName: "Design Daily", username: "designdaily", text: "Good mobile design respects your time, battery, and connection.", timestamp: .now.addingTimeInterval(-7200), avatarURL: nil, imageURL: nil, replies: 31, reposts: 77, likes: 512, views: 18000, verified: true, liked: false, reposted: false, bookmarked: true)
    ]
}
