import Foundation

enum XitterAPIError: LocalizedError {
    case invalidResponse
    case httpStatus(Int)
    case invalidCredentials
    case missingSessionCookies
    case invalidInstance

    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "The instance returned an unexpected response."
        case .httpStatus(let code): return "The instance returned HTTP \(code)."
        case .invalidCredentials: return "Wrong username or password."
        case .missingSessionCookies: return "The instance did not return the expected session cookies."
        case .invalidInstance: return "Enter a valid instance URL."
        }
    }
}

/// Uses the Xitter server's actual POST /login form endpoint.
/// No example token or cookie is embedded in the app.
struct XitterAPI {
    let baseURL: URL

    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.waitsForConnectivity = true
        config.timeoutIntervalForRequest = 25
        config.timeoutIntervalForResource = 60
        config.requestCachePolicy = .useProtocolCachePolicy
        config.httpCookieStorage = .shared
        config.httpShouldSetCookies = true
        config.httpCookieAcceptPolicy = .always
        config.urlCache = URLCache(memoryCapacity: 32 * 1024 * 1024,
                                   diskCapacity: 128 * 1024 * 1024,
                                   diskPath: "xitter-http-cache")
        return URLSession(configuration: config)
    }()

    /// Server handleLogin expects application/x-www-form-urlencoded username/password.
    /// A successful login sets auth_token (HttpOnly), ct0 and twid, then redirects to /home.
    func signIn(username: String, password: String) async throws {
        guard let url = URL(string: "/login", relativeTo: baseURL)?.absoluteURL,
              ["https", "http"].contains(url.scheme?.lowercased() ?? ""),
              url.host == baseURL.host else {
            throw XitterAPIError.invalidInstance
        }

        clearSessionCookies(for: baseURL)

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpShouldHandleCookies = true
        request.setValue("application/x-www-form-urlencoded; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.setValue("text/html,application/xhtml+xml", forHTTPHeaderField: "Accept")
        request.setValue("XitterNative-iOS", forHTTPHeaderField: "User-Agent")

        var form = URLComponents()
        form.queryItems = [
            URLQueryItem(name: "username", value: username.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "@", with: "", options: [.anchored])),
            URLQueryItem(name: "password", value: password)
        ]
        request.httpBody = form.percentEncodedQuery?.data(using: .utf8)

        let (_, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw XitterAPIError.invalidResponse }
        if http.statusCode == 401 { throw XitterAPIError.invalidCredentials }
        guard (200..<400).contains(http.statusCode) else { throw XitterAPIError.httpStatus(http.statusCode) }

        let cookies = HTTPCookieStorage.shared.cookies(for: baseURL) ?? []
        let names = Set(cookies.map(\.name))
        guard names.contains("auth_token"), names.contains("ct0") else {
            throw XitterAPIError.missingSessionCookies
        }
    }

    func hasSession() -> Bool {
        let names = Set((HTTPCookieStorage.shared.cookies(for: baseURL) ?? []).map(\.name))
        return names.contains("auth_token") && names.contains("ct0")
    }

    func clearSessionCookies(for url: URL) {
        for cookie in HTTPCookieStorage.shared.cookies(for: url) ?? []
        where ["auth_token", "ct0", "twid"].contains(cookie.name) {
            HTTPCookieStorage.shared.deleteCookie(cookie)
        }
    }

    /// Reads the instance's real X-compatible timeline operation. The server routes
    /// by the final operation name; its current graphql.ts maps HomeTimeline to For You
    /// and HomeLatestTimeline to Following. GET requests use variables in the query.
    func fetchTimeline(kind: String) async throws -> [Post] {
        let operation = kind == "Following" ? "HomeLatestTimeline" : "HomeTimeline"
        var components = URLComponents(url: baseURL.appendingPathComponent("i/api/graphql/native/\(operation)"), resolvingAgainstBaseURL: false)
        let variables: [String: Any] = ["count": 30, "cursor": "", "seenTweetIds": [] as [String]]
        let encoded = try JSONSerialization.data(withJSONObject: variables, options: [.sortedKeys])
        guard let variablesText = String(data: encoded, encoding: .utf8) else { throw XitterAPIError.invalidResponse }
        components?.queryItems = [URLQueryItem(name: "variables", value: variablesText)]
        guard let url = components?.url else { throw XitterAPIError.invalidInstance }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.httpShouldHandleCookies = true
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("XitterNative-iOS", forHTTPHeaderField: "User-Agent")
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw XitterAPIError.invalidResponse }
        guard http.statusCode == 200 else { throw XitterAPIError.httpStatus(http.statusCode) }
        return try Self.decodeTimeline(data)
    }

    private static func decodeTimeline(_ data: Data) throws -> [Post] {
        let root = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        let dataObject = root?["data"] as? [String: Any]
        let home = dataObject?["home"] as? [String: Any]
        let timeline = home?["home_timeline_urt"] as? [String: Any]
        let instructions = timeline?["instructions"] as? [[String: Any]] ?? []
        var posts: [Post] = []
        var seen = Set<String>()

        for instruction in instructions where (instruction["type"] as? String) == "TimelineAddEntries" {
            let entries = instruction["entries"] as? [[String: Any]] ?? []
            for entry in entries {
                let content = entry["content"] as? [String: Any]
                let itemContent = content?["itemContent"] as? [String: Any]
                let tweetResults = itemContent?["tweet_results"] as? [String: Any]
                guard let result = tweetResults?["result"] as? [String: Any] else { continue }
                // Some Xitter responses wrap a restricted tweet in TweetWithVisibilityResults.
                let tweet = (result["tweet"] as? [String: Any]) ?? result
                guard let id = tweet["rest_id"] as? String, seen.insert(id).inserted else { continue }
                let legacy = tweet["legacy"] as? [String: Any] ?? [:]
                let core = tweet["core"] as? [String: Any]
                let userResults = core?["user_results"] as? [String: Any]
                let user = userResults?["result"] as? [String: Any] ?? [:]
                let userCore = user["core"] as? [String: Any] ?? [:]
                let name = userCore["name"] as? String ?? "Unknown"
                let username = userCore["screen_name"] as? String ?? "unknown"
                let text = legacy["full_text"] as? String ?? legacy["text"] as? String ?? ""
                let createdAt = Self.parseDate(legacy["created_at"] as? String) ?? .now
                let avatarString = (user["avatar"] as? [String: Any])?["image_url"] as? String
                let avatar = avatarString.flatMap(URL.init(string:))
                let media = (legacy["extended_entities"] as? [String: Any])?["media"] as? [[String: Any]]
                    ?? (legacy["entities"] as? [String: Any])?["media"] as? [[String: Any]] ?? []
                let mediaString = media.first?["media_url_https"] as? String ?? media.first?["media_url"] as? String
                let image = mediaString.flatMap(URL.init(string:))
                let verified = user["is_blue_verified"] as? Bool ?? false
                let views = Int(((tweet["views"] as? [String: Any])?["count"] as? String) ?? "0") ?? 0
                posts.append(Post(
                    id: id, displayName: name, username: username, text: text,
                    timestamp: createdAt, avatarURL: avatar, imageURL: image,
                    replies: legacy["reply_count"] as? Int ?? 0,
                    reposts: legacy["retweet_count"] as? Int ?? 0,
                    likes: legacy["favorite_count"] as? Int ?? 0,
                    views: views, verified: verified,
                    liked: legacy["favorited"] as? Bool ?? false,
                    reposted: legacy["retweeted"] as? Bool ?? false,
                    bookmarked: legacy["bookmarked"] as? Bool ?? false
                ))
            }
        }
        return posts
    }

    private static func parseDate(_ raw: String?) -> Date? {
        guard let raw else { return nil }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "EEE MMM dd HH:mm:ss Z yyyy"
        return formatter.date(from: raw)
    }

    func request(path: String, method: String = "GET", body: Data? = nil) async throws -> Data {
        guard let url = URL(string: path, relativeTo: baseURL) else { throw XitterAPIError.invalidInstance }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.httpBody = body
        request.httpShouldHandleCookies = true
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if body != nil { request.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw XitterAPIError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else { throw XitterAPIError.httpStatus(http.statusCode) }
        return data
    }
}
