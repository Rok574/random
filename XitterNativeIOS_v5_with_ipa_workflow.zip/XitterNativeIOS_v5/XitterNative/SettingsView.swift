import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var settings: InstanceSettings
    @Environment(\.dismiss) private var dismiss
    var isStandalone = false
    @State private var draft = ""
    @State private var error: String?
    @State private var saved = false
    @State private var showSignOut = false

    var body: some View {
        Form {
            Section("Instance") {
                TextField("https://instance.example", text: $draft)
                    .textInputAutocapitalization(.never)
                    .keyboardType(.URL)
                    .autocorrectionDisabled()
                Text("Current: \(settings.baseURL?.host ?? "Invalid URL")")
                    .font(.caption).foregroundStyle(.secondary)
                if let error { Text(error).font(.caption).foregroundStyle(.red) }
                Button("Save instance URL") {
                    settings.baseURLString = draft
                    if settings.normalizeInstanceURL() {
                        saved = true
                        error = nil
                    } else {
                        error = "Enter a valid http:// or https:// URL."
                    }
                }
                if saved {
                    Label("Instance saved", systemImage: "checkmark.circle.fill").foregroundStyle(.green)
                }
            }

            Section("Connection") {
                LabeledContent("Timeline mode", value: AppConfig.demoMode ? "Preview" : "Live")
                LabeledContent("Interface", value: "Native SwiftUI")
                Text("Sign-in uses the instance login form. Timeline and post controls are still preview-only and change local demo data.")
                    .font(.caption).foregroundStyle(.secondary)
            }

            Section("Local data") {
                Button("Clear cached timeline", role: .destructive) {
                    let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
                    try? FileManager.default.removeItem(at: dir.appendingPathComponent("xitter-feed-v1.json"))
                }
            }

            if settings.signedInUsername != nil {
                Section("Account") {
                    Button("Sign out", role: .destructive) { showSignOut = true }
                }
            }

            Section {
                Link("Xitter source code", destination: URL(string: "https://github.com/Xittered/xitter")!)
                Text("This is an independent native client starter. Xitter's server API contract must be verified before live account operations are enabled.")
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
        .scrollContentBackground(.hidden)
        .background(Color.black)
        .navigationTitle("Settings")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if isStandalone {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
        }
        .onAppear { draft = settings.baseURLString }
        .confirmationDialog("Sign out of this app?", isPresented: $showSignOut, titleVisibility: .visible) {
            Button("Sign out", role: .destructive) {
                if let url = settings.baseURL {
                    XitterAPI(baseURL: url).clearSessionCookies(for: url)
                }
                settings.signOutLocally()
                settings.hasCompletedSetup = true
                dismiss()
            }
        } message: {
            Text("Local app sign-in state will be cleared.")
        }
    }
}
